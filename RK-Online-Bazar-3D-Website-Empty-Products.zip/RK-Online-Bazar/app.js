const defaultProducts = [];
const $ = s => document.querySelector(s);
let products = JSON.parse(localStorage.getItem("rk_products") || "null") || defaultProducts;
let cart = JSON.parse(localStorage.getItem("rk_cart") || "[]");
let activeCategory = "सभी";
let searchTerm = "";
const save = () => { localStorage.setItem("rk_products",JSON.stringify(products)); localStorage.setItem("rk_cart",JSON.stringify(cart)); };
const money = n => "₹"+Number(n).toLocaleString("en-IN");
function renderProducts(){
 const list=products.filter(p=>(activeCategory==="सभी"||p.category===activeCategory)&&(`${p.name} ${p.category} ${p.shop||""}`).toLowerCase().includes(searchTerm.toLowerCase()));
 $("#productCount").textContent=`${list.length} उत्पाद`;
 $("#productGrid").innerHTML=list.length?list.map(p=>`<article class="product-card"><div class="product-image">${p.image?`<img src="${escapeHtml(p.image)}" alt="${escapeHtml(p.name)}" onerror="this.remove()">`:p.emoji||"📦"}</div><div class="product-info"><span class="product-category">${escapeHtml(p.category)}</span><h3>${escapeHtml(p.name)}</h3><small style="color:#929db7;font-size:10px">${escapeHtml(p.shop||"स्थानीय दुकानदार")}</small><div class="product-meta"><span class="price">${money(p.price)}</span><button class="add-btn" aria-label="कार्ट में जोड़ें" data-add="${p.id}">+</button></div></div></article>`).join(""):`<div class="no-results">इस कैटेगरी में कोई सामान नहीं मिला।</div>`;
}
function escapeHtml(v){return String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function renderCart(){
 const count=cart.reduce((s,x)=>s+x.qty,0),total=cart.reduce((s,x)=>s+x.price*x.qty,0);
 $("#cartCount").textContent=count;$("#cartTotal").textContent=money(total);$("#checkoutTotal").textContent=money(total);
 $("#cartItems").innerHTML=cart.length?cart.map(x=>`<div class="cart-line"><div class="cart-thumb">${x.emoji||"📦"}</div><div class="cart-line-info"><b>${escapeHtml(x.name)}</b><small>${money(x.price)} each</small></div><div class="qty"><button data-minus="${x.id}">−</button><b>${x.qty}</b><button data-plus="${x.id}">+</button></div></div>`).join(""):`<div class="empty-state">🛍️<br><br>आपका कार्ट अभी खाली है।</div>`;
}
function showLayer(el){$("#overlay").classList.add("show");el.classList.add("open");}
function closeLayers(){$("#overlay").classList.remove("show");document.querySelectorAll(".drawer,.modal").forEach(x=>x.classList.remove("open"));}
function openCart(){renderCart();showLayer($("#cartDrawer"));}
function openSeller(){showLayer($("#sellerModal"));}
$("#productGrid").addEventListener("click",e=>{const b=e.target.closest("[data-add]");if(!b)return;const p=products.find(x=>x.id==b.dataset.add);const item=cart.find(x=>x.id===p.id);if(item)item.qty++;else cart.push({...p,qty:1});save();renderCart();b.textContent="✓";setTimeout(()=>b.textContent="+",700);});
$("#categories").addEventListener("click",e=>{const b=e.target.closest("button[data-category]");if(!b)return;activeCategory=b.dataset.category;document.querySelectorAll("#categories button").forEach(x=>x.classList.toggle("active",x===b));renderProducts();});
$("#searchInput").addEventListener("input",e=>{searchTerm=e.target.value;renderProducts();});
$("#cartOpen").onclick=openCart;$("#sellerOpen").onclick=openSeller;$("#sellerOpen2").onclick=openSeller;
$("#overlay").onclick=closeLayers;document.querySelectorAll("[data-close]").forEach(b=>b.onclick=closeLayers);
$("#cartItems").addEventListener("click",e=>{const plus=e.target.closest("[data-plus]"),minus=e.target.closest("[data-minus]");if(!plus&&!minus)return;const id=Number((plus||minus).dataset[plus?"plus":"minus"]);const item=cart.find(x=>x.id===id);if(plus)item.qty++;else if(--item.qty<=0)cart=cart.filter(x=>x.id!==id);save();renderCart();});
$("#sellerForm").addEventListener("submit",e=>{e.preventDefault();const f=new FormData(e.target);products.unshift({id:Date.now(),name:f.get("name"),price:Number(f.get("price")),category:f.get("category"),image:f.get("image"),shop:f.get("shop")||"स्थानीय दुकानदार",emoji:"📦"});save();renderProducts();e.target.reset();closeLayers();alert("उत्पाद इस ब्राउज़र में जोड़ दिया गया है!");});
$("#checkoutBtn").onclick=()=>{if(!cart.length){alert("पहले कार्ट में सामान जोड़ें।");return;}closeLayers();showLayer($("#checkoutModal"));};
$("#checkoutForm").addEventListener("submit",e=>{e.preventDefault();const f=new FormData(e.target);const order={id:"RK"+Date.now(),customer:f.get("customer"),phone:f.get("phone"),address:f.get("address"),items:cart,total:cart.reduce((s,x)=>s+x.price*x.qty,0),date:new Date().toLocaleString("hi-IN")};const orders=JSON.parse(localStorage.getItem("rk_demo_orders")||"[]");orders.unshift(order);localStorage.setItem("rk_demo_orders",JSON.stringify(orders));cart=[];save();renderCart();$("#successText").textContent=`ऑर्डर ${order.id} इस डिवाइस के ब्राउज़र में सेव हुआ है। यह वास्तविक दुकान/डिलीवरी को नहीं भेजा गया।`;e.target.reset();closeLayers();showLayer($("#successModal"));});
renderProducts();renderCart();
