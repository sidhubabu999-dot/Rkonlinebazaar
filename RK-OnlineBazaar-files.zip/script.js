const products = [
  {id:1,name:"ताज़ी सब्ज़ियाँ",category:"किराना",price:40,unit:"प्रति पैकेट",icon:"🥦",shop:"स्थानीय किराना दुकान"},
  {id:2,name:"बासमती चावल",category:"किराना",price:120,unit:"1 किलो",icon:"🍚",shop:"अपना जनरल स्टोर"},
  {id:3,name:"कॉटन टी-शर्ट",category:"फैशन",price:299,unit:"प्रति पीस",icon:"👕",shop:"RK फैशन हाउस"},
  {id:4,name:"वायरलेस ईयरबड्स",category:"इलेक्ट्रॉनिक्स",price:599,unit:"प्रति पीस",icon:"🎧",shop:"मोबाइल ज़ोन"},
  {id:5,name:"किचन कंटेनर सेट",category:"घर और किचन",price:249,unit:"1 सेट",icon:"🍱",shop:"होम नीड्स"},
  {id:6,name:"गिफ्ट बॉक्स",category:"गिफ्ट",price:199,unit:"प्रति बॉक्स",icon:"🎁",shop:"गिफ्ट कॉर्नर"},
  {id:7,name:"स्किन केयर किट",category:"ब्यूटी",price:349,unit:"1 किट",icon:"🧴",shop:"ब्यूटी कलेक्शन"},
  {id:8,name:"स्पोर्ट्स शूज़",category:"फैशन",price:799,unit:"प्रति जोड़ी",icon:"👟",shop:"RK फैशन हाउस"}
];
let cart = JSON.parse(localStorage.getItem("rkCart") || "[]");
let activeCategory = "सभी";
const grid = document.getElementById("productGrid");
function renderProducts(){
  const term = document.getElementById("search").value.trim().toLowerCase();
  const filtered = products.filter(p => (activeCategory==="सभी" || p.category===activeCategory) && (p.name.toLowerCase().includes(term) || p.shop.toLowerCase().includes(term)));
  grid.innerHTML = filtered.length ? filtered.map(p=>`<article class="product-card"><div class="product-image">${p.icon}</div><h3>${p.name}</h3><p>${p.shop} • ${p.unit}</p><div class="price-row"><span class="price">₹${p.price}</span><button class="add-button" data-add="${p.id}">+ जोड़ें</button></div></article>`).join("") : "<p>इस खोज में कोई सामान नहीं मिला।</p>";
}
function updateCart(){
  localStorage.setItem("rkCart",JSON.stringify(cart));
  document.getElementById("cartCount").textContent=cart.reduce((s,x)=>s+x.qty,0);
}
document.getElementById("categories").addEventListener("click",e=>{
  const btn=e.target.closest("[data-category]"); if(!btn)return;
  activeCategory=btn.dataset.category;
  document.querySelectorAll(".category").forEach(b=>b.classList.toggle("active",b===btn));
  renderProducts();
});
grid.addEventListener("click",e=>{
  const btn=e.target.closest("[data-add]"); if(!btn)return;
  const id=Number(btn.dataset.add), item=cart.find(x=>x.id===id);
  if(item)item.qty++; else cart.push({id,qty:1});
  updateCart(); btn.textContent="जुड़ गया ✓"; setTimeout(()=>btn.textContent="+ जोड़ें",900);
});
document.getElementById("search").addEventListener("input",renderProducts);
const dialog=document.getElementById("cartDialog");
document.getElementById("cartButton").onclick=()=>{
  const area=document.getElementById("cartItems");
  area.innerHTML=cart.length?cart.map(x=>{const p=products.find(y=>y.id===x.id);return `<div class="cart-line"><span>${p.name} × ${x.qty}</span><b>₹${p.price*x.qty}</b></div>`}).join(""):"<p>आपका कार्ट खाली है।</p>";
  document.getElementById("cartTotal").textContent="₹"+cart.reduce((s,x)=>s+products.find(p=>p.id===x.id).price*x.qty,0);
  dialog.showModal();
};
document.getElementById("closeCart").onclick=()=>dialog.close();
document.getElementById("sellerForm").addEventListener("submit",e=>{
  e.preventDefault();
  document.getElementById("sellerMessage").textContent="डेमो में जानकारी केवल इसी ब्राउज़र पर दिखाई गई है। असली रजिस्ट्रेशन अभी सक्रिय नहीं है।";
  e.target.reset();
});
renderProducts();updateCart();
